<?php
$a =  $args; // artist object from artist page
?>
<aside>
	<!-- <div class="has-matte">
		<?= $a->get_artist_image(null, array('class' => 'img-fluid')); ?> 
	</div> -->
</aside>